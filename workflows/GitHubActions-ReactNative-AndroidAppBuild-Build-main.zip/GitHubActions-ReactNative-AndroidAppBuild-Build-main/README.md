# GitHubActions-ReactNative-AndroidAppBuild-Build
 Exemplo de workflow do GitHub Actions em ambiente macOS para build de um app React Native em Android utilizando o formato .aab (Android App Bundles)..
