# GitHubActions-ReactNative-Android-Build
Exemplo de workflow do GitHub Actions em ambiente macOS para build de um app React Native em Android.

Aplicação utilizada como base:
https://github.com/renatogroffe/ReactNative-AppHelloWorld
